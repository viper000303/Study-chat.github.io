STUDYCHAT WEBSITE DOWNLOAD
==========================

This ZIP contains the complete StudyChat website download.

site/
  Ready-to-upload static website files. Upload the contents of this folder to a static host.

source/
  Editable StudyChat React/Vite source code.

attached_assets/
  Required StudyChat logo asset.

To run the editable source locally from this folder:
  1. Install pnpm.
  2. Run: pnpm install
  3. Run: PORT=5173 BASE_PATH=/ pnpm --filter @workspace/studychat run dev

The website stores chats and settings locally in the browser. AI responses are local demo behavior until a provider is connected.
