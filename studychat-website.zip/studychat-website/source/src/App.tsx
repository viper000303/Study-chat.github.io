import { useEffect, useMemo, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import {
  Archive,
  ArrowUp,
  BookOpen,
  Check,
  ChevronDown,
  ChevronLeft,
  CircleHelp,
  Code2,
  Download,
  File,
  FileImage,
  FolderPlus,
  Globe2,
  GraduationCap,
  Image,
  KeyRound,
  Library,
  Lock,
  Menu,
  MessageSquare,
  MessageSquarePlus,
  Moon,
  MoreHorizontal,
  Paperclip,
  Palette,
  Plus,
  Search,
  Settings,
  Sparkles,
  Sun,
  Trash2,
  Upload,
  UserRound,
  Video,
  X,
  Zap,
} from 'lucide-react';
import logoAsset from '@assets/IMG_0737_1790367913022.png';

const queryClient = new QueryClient();
const CHAT_KEY = 'studychat-chats-v2';
const PROJECT_KEY = 'studychat-projects-v2';
const THEME_KEY = 'studychat-theme-v2';
const SCHOOL_KEY = 'studychat-school-v2';
const MODEL_KEY = 'studychat-model-v2';
const SCHOOL_ENABLED_KEY = 'studychat-school-enabled-v2';
const CUSTOM_KEY = 'studychat-custom-v2';

type Message = { id: string; role: 'user' | 'assistant'; content: string; image?: boolean; createdAt: number };
type Chat = { id: string; title: string; messages: Message[]; updatedAt: number };
type Project = { id: string; name: string; count: number };
type SchoolState = { grade: string; subject: string; customSubjects: string[] };
type Attachment = { id: string; name: string; kind: 'image' | 'video' | 'file' };
type ModelId = 'chatgpt' | 'gemini' | 'claude';
type CustomState = { accent: string; density: 'cozy' | 'compact'; showHints: boolean };
type ModalType = 'school' | 'project' | 'customize' | null;

const gradeSubjects: Record<string, string[]> = {
  '6th grade': ['Math', 'English Language Arts', 'Earth Science', 'Ancient World History', 'Geography', 'Spanish', 'Art', 'Music', 'Health & PE', 'Computer Science'],
  '7th grade': ['Math', 'English Language Arts', 'Life Science', 'World History', 'Geography', 'Spanish', 'Art', 'Music', 'Health & PE', 'Computer Science'],
  '8th grade': ['Pre-Algebra', 'English Language Arts', 'Physical Science', 'Civics', 'Geography', 'Spanish', 'Art', 'Music', 'Health & PE', 'Computer Science'],
};

const models: { id: ModelId; label: string; detail: string; locked?: boolean }[] = [
  { id: 'chatgpt', label: 'ChatGPT Auto', detail: 'Fast and balanced' },
  { id: 'gemini', label: 'Gemini Pro 3', detail: 'Long context and research', locked: true },
  { id: 'claude', label: 'Claude Best Model', detail: 'Thoughtful writing and analysis', locked: true },
];

const starterSuggestions = [
  { label: 'Create image', icon: Image, prompt: 'Create an image of a cozy library on another planet' },
  { label: 'Analyze images', icon: Image, prompt: 'Help me analyze this image' },
  { label: 'Summarize text', icon: File, prompt: 'Summarize the most important ideas in this text' },
  { label: 'Code', icon: Code2, prompt: 'Help me write a small program' },
  { label: 'Help me write', icon: Sparkles, prompt: 'Help me write a clear first draft' },
  { label: 'Brainstorm', icon: Zap, prompt: 'Brainstorm ideas for my next project' },
];

const makeId = () => `${Date.now()}-${Math.random().toString(16).slice(2)}`;
const load = <T,>(key: string, fallback: T): T => {
  try {
    const value = localStorage.getItem(key);
    return value ? (JSON.parse(value) as T) : fallback;
  } catch {
    return fallback;
  }
};

function StudyChat() {
  const [theme, setTheme] = useState<'light' | 'dark'>(() => load(THEME_KEY, 'dark') as 'light' | 'dark');
  const [chats, setChats] = useState<Chat[]>(() => load<Chat[]>(CHAT_KEY, []));
  const [projects, setProjects] = useState<Project[]>(() => load<Project[]>(PROJECT_KEY, [{ id: 'starter-project', name: 'My study space', count: 0 }]));
  const [school, setSchool] = useState<SchoolState>(() => load<SchoolState>(SCHOOL_KEY, { grade: '7th grade', subject: 'Math', customSubjects: [] }));
  const [schoolEnabled, setSchoolEnabled] = useState<boolean>(() => load(SCHOOL_ENABLED_KEY, false));
  const [model, setModel] = useState<ModelId>(() => load(MODEL_KEY, 'chatgpt') as ModelId);
  const [custom, setCustom] = useState<CustomState>(() => load(CUSTOM_KEY, { accent: 'teal', density: 'cozy', showHints: true }));
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [searchOpen, setSearchOpen] = useState(false);
  const [draft, setDraft] = useState('');
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [imageMode, setImageMode] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [modal, setModal] = useState<ModalType>(null);
  const [profileOpen, setProfileOpen] = useState(false);
  const [modelOpen, setModelOpen] = useState(false);
  const [toast, setToast] = useState('');
  const [dragging, setDragging] = useState(false);
  const [projectName, setProjectName] = useState('');
  const [customSubject, setCustomSubject] = useState('');
  const [secretOpen, setSecretOpen] = useState(false);
  const [secretCode, setSecretCode] = useState('');
  const [secretUnlocked, setSecretUnlocked] = useState(false);
  const [secretError, setSecretError] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const composerRef = useRef<HTMLTextAreaElement>(null);

  const activeChat = chats.find((chat) => chat.id === activeChatId);
  const filteredChats = useMemo(() => chats.filter((chat) => chat.title.toLowerCase().includes(search.toLowerCase())), [chats, search]);
  const subjects = [...(gradeSubjects[school.grade] ?? []), ...school.customSubjects];
  const selectedModel = models.find((item) => item.id === model) ?? models[0];

  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
    localStorage.setItem(THEME_KEY, theme);
  }, [theme]);
  useEffect(() => { localStorage.setItem(CHAT_KEY, JSON.stringify(chats)); }, [chats]);
  useEffect(() => { localStorage.setItem(PROJECT_KEY, JSON.stringify(projects)); }, [projects]);
  useEffect(() => { localStorage.setItem(SCHOOL_KEY, JSON.stringify(school)); }, [school]);
  useEffect(() => { localStorage.setItem(SCHOOL_ENABLED_KEY, JSON.stringify(schoolEnabled)); }, [schoolEnabled]);
  useEffect(() => { localStorage.setItem(MODEL_KEY, JSON.stringify(model)); }, [model]);
  useEffect(() => { localStorage.setItem(CUSTOM_KEY, JSON.stringify(custom)); }, [custom]);
  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(''), 2500);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const chooseChat = (id: string) => { setActiveChatId(id); setMobileOpen(false); setDraft(''); };
  const newChat = () => { setActiveChatId(null); setDraft(''); setAttachments([]); setMobileOpen(false); setModelOpen(false); composerRef.current?.focus(); };
  const deleteChat = (id: string) => { setChats((items) => items.filter((item) => item.id !== id)); if (activeChatId === id) setActiveChatId(null); setToast('Chat archived'); };
  const addFiles = (files: FileList | File[]) => {
    const incoming = Array.from(files).slice(0, 8).map((file) => ({
      id: makeId(),
      name: file.name,
      kind: file.type.startsWith('image/') ? 'image' as const : file.type.startsWith('video/') ? 'video' as const : 'file' as const,
    }));
    if (incoming.length) {
      setAttachments((current) => [...current, ...incoming].slice(0, 8));
      setToast(`${incoming.length} file${incoming.length > 1 ? 's' : ''} attached`);
    }
  };
  const onDrop = (event: React.DragEvent<HTMLDivElement>) => { event.preventDefault(); setDragging(false); addFiles(event.dataTransfer.files); };
  const submit = (value = draft) => {
    const clean = value.trim();
    if (!clean || isGenerating) return;
    if (clean.toUpperCase() === 'SECRET') {
      setSecretOpen(true);
      setSecretCode('');
      setSecretError(false);
      setDraft('');
      return;
    }
    const now = Date.now();
    const visual = imageMode || clean.toLowerCase().startsWith('create image');
    const userMessage: Message = { id: makeId(), role: 'user', content: clean, createdAt: now };
    const response: Message = {
      id: makeId(),
      role: 'assistant',
      image: visual,
      createdAt: now + 1,
      content: visual
        ? `I created a visual direction for “${clean}” using ${selectedModel.label}. You can keep refining the prompt or attach a reference image.`
        : buildResponse(clean, school, schoolEnabled, selectedModel.label),
    };
    let targetId = activeChatId;
    if (!targetId) {
      targetId = makeId();
      setActiveChatId(targetId);
      setChats((items) => [{ id: targetId!, title: clean.slice(0, 42), messages: [userMessage], updatedAt: now }, ...items]);
    } else {
      setChats((items) => items.map((chat) => chat.id === targetId ? { ...chat, messages: [...chat.messages, userMessage], updatedAt: now } : chat));
    }
    setDraft('');
    setAttachments([]);
    setIsGenerating(true);
    setMobileOpen(false);
    window.setTimeout(() => {
      setChats((items) => items.map((chat) => chat.id === targetId ? { ...chat, messages: [...chat.messages, response], updatedAt: Date.now() } : chat));
      setIsGenerating(false);
    }, visual ? 1300 : 850);
  };
  const toggleSchool = () => {
    const next = !schoolEnabled;
    setSchoolEnabled(next);
    setToast(next ? 'School mode is on' : 'School mode is off');
    if (next) setModal('school');
  };
  const saveSchool = () => { setModal(null); setToast(`${school.grade} · ${school.subject} focus saved`); };
  const createProject = () => {
    const name = projectName.trim();
    if (!name) return;
    setProjects((items) => [...items, { id: makeId(), name, count: 0 }]);
    setProjectName('');
    setModal(null);
    setToast(`Project “${name}” created`);
  };
  const addCustomSubject = () => {
    const subject = customSubject.trim();
    if (!subject || school.customSubjects.includes(subject)) return;
    setSchool((current) => ({ ...current, customSubjects: [...current.customSubjects, subject], subject }));
    setCustomSubject('');
  };
  const openSecret = () => {
    setSecretOpen(true);
    setSecretCode('');
    setSecretError(false);
    setModelOpen(false);
  };
  const handleSecretKey = (key: string) => {
    if (key === 'back') {
      setSecretCode((value) => value.slice(0, -1));
      setSecretError(false);
      return;
    }
    if (secretCode.length >= 4) return;
    const next = `${secretCode}${key}`;
    setSecretCode(next);
    if (next.length === 4) {
      if (next === '2671') {
        setSecretUnlocked(true);
        setSecretError(false);
        setToast('Creator access unlocked');
      } else {
        setSecretError(true);
        window.setTimeout(() => setSecretCode(''), 400);
      }
    }
  };
  const downloadFile = (name: string, contents: string, type: string) => {
    const blob = new Blob([contents], { type });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = name;
    anchor.click();
    URL.revokeObjectURL(url);
  };
  const downloadWorkspace = () => {
    const exportData = {
      name: 'StudyChat AI Workspace',
      exportedAt: new Date().toISOString(),
      note: 'This export contains the saved workspace data. The React/Vite source is available in the project files for GitHub.',
      theme,
      model,
      school,
      schoolEnabled,
      customization: custom,
      projects,
      chats,
    };
    downloadFile('studychat-workspace.json', JSON.stringify(exportData, null, 2), 'application/json');
    setToast('Workspace download started');
  };
  const downloadGitHubReadme = () => {
    downloadFile('STUDYCHAT-GITHUB-README.md', '# StudyChat AI Workspace\n\nA ChatGPT-style learning workspace with projects, file uploads, School mode, image mode, themes, model switching, and local persistence.\n\n## Run locally\n\n```bash\npnpm install\npnpm --filter @workspace/studychat run dev\n```\n\nThe source code in this Replit project is ready to push to GitHub.', 'text/markdown');
    setToast('GitHub README download started');
  };
  const downloadWebsite = () => {
    const anchor = document.createElement('a');
    anchor.href = `${import.meta.env.BASE_URL}studychat-website.zip`;
    anchor.download = 'studychat-website.zip';
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setToast('Website ZIP download started');
  };

  return (
    <div className={`study-app accent-${custom.accent} density-${custom.density}`}>
      {mobileOpen && <div className="mobile-scrim" onClick={() => setMobileOpen(false)} data-testid="button-close-sidebar" />}
      <aside className={`sidebar ${mobileOpen ? 'open' : ''}`}>
        <div className="brand-row">
          <button className="brand" onClick={newChat} data-testid="button-brand-new-chat">
            <img className="brand-logo" src={logoAsset} alt="StudyChat logo" />
            <span className="brand-word">Study<span>Chat</span></span>
          </button>
          <button className="icon-button" onClick={() => setMobileOpen(false)} aria-label="Close sidebar" data-testid="button-sidebar-close"><ChevronLeft size={17} /></button>
        </div>
        <button className="new-chat-button" onClick={newChat} data-testid="button-new-chat"><MessageSquarePlus size={17} /><span>New chat</span><span className="shortcut">N</span></button>
        <button className="side-link" onClick={() => { setSearchOpen(true); window.setTimeout(() => document.querySelector<HTMLInputElement>('[data-testid="input-search-chats"]')?.focus(), 0); }} data-testid="button-search-chats"><Search size={16} /><span>Search chats</span></button>
        <div className="sidebar-section">
          <div className="section-label"><span>Projects</span><button className="section-add" onClick={() => setModal('project')} aria-label="New project" data-testid="button-create-project"><Plus size={15} /></button></div>
          <button className="side-link" onClick={() => setModal('project')} data-testid="button-new-project"><FolderPlus size={16} /><span>New project</span></button>
          {projects.map((project) => <button className="project-item" key={project.id} onClick={() => setToast(`${project.name} is ready for your next chat`)} data-testid={`button-project-${project.id}`}><i className="project-dot" /><span>{project.name}</span></button>)}
        </div>
        <div className="sidebar-section chats-section">
          <div className="section-label"><span>Chats</span><span>{chats.length || ''}</span></div>
          {searchOpen && <label className="search-box"><Search size={14} /><input type="search" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search chats" aria-label="Search chats" data-testid="input-search-chats" /><button className="search-close" onClick={() => { setSearch(''); setSearchOpen(false); }} aria-label="Close chat search"><X size={13} /></button></label>}
          <div className="history-list">
            {filteredChats.length ? filteredChats.map((chat) => (
              <div className={`chat-item ${activeChatId === chat.id ? 'active' : ''}`} key={chat.id}>
                <button onClick={() => chooseChat(chat.id)} data-testid={`button-chat-${chat.id}`}><MessageSquare size={14} /><span>{chat.title}</span></button>
                <button className="delete-chat" onClick={() => deleteChat(chat.id)} aria-label={`Archive ${chat.title}`} data-testid={`button-archive-chat-${chat.id}`}><Archive size={13} /></button>
              </div>
            )) : <div className="empty-history">{search ? 'No chats match that search.' : 'Your recent chats will appear here.'}</div>}
          </div>
        </div>
        <div className="sidebar-footer">
          <button className="profile-button" onClick={() => setProfileOpen((open) => !open)} data-testid="button-sidebar-profile"><span className="avatar">MT</span><span className="profile-copy"><span className="profile-name">Maya Thompson</span><span className="profile-plan">Student plan</span></span><MoreHorizontal size={15} /></button>
        </div>
      </aside>
      <main className="main-shell">
        <header className="topbar">
          <div className="topbar-left">
            <button className="icon-button mobile-menu" onClick={() => setMobileOpen(true)} aria-label="Open sidebar" data-testid="button-open-sidebar"><Menu size={18} /></button>
            <div className="page-title"><span>{activeChat ? activeChat.title : 'ChatGPT'}</span>{!activeChat && <button className="model-button" onClick={() => setModelOpen((open) => !open)} data-testid="button-model-menu">{selectedModel.label}<ChevronDown size={14} /></button>}</div>
            {modelOpen && <div className="model-menu">{models.map((item) => <button className={`model-option ${item.id === model ? 'selected' : ''}`} key={item.id} onClick={() => { if (item.locked && !secretUnlocked) { openSecret(); return; } setModel(item.id); setModelOpen(false); setToast(`${item.label} selected`); }} data-testid={`button-model-${item.id}`}><span className="model-icon">{item.id === 'chatgpt' ? <Sparkles size={14} /> : item.id === 'gemini' ? <Globe2 size={14} /> : <Zap size={14} />}</span><span><strong>{item.label}</strong><small>{item.detail}</small></span>{item.locked && !secretUnlocked ? <Lock size={13} /> : item.id === model ? <Check size={13} /> : null}</button>)}</div>}
          </div>
          <div className="topbar-right">
            <button className={`school-toggle ${schoolEnabled ? 'on' : ''}`} onClick={toggleSchool} data-testid="button-school-mode"><GraduationCap size={15} /><span>School mode</span><i className="toggle-track"><b /></i></button>
            <button className="icon-button customize-button" onClick={() => setModal('customize')} aria-label="Customize workspace" data-testid="button-customize"><Palette size={17} /></button>
            <button className="icon-button theme-button" onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')} aria-label="Toggle theme" data-testid="button-toggle-theme">{theme === 'light' ? <Moon size={17} /> : <Sun size={17} />}</button>
            <div className="user-menu-wrap"><button className="user-avatar" onClick={() => setProfileOpen((open) => !open)} aria-label="Open account menu" data-testid="button-user-menu">MT</button>{profileOpen && <div className="user-menu"><div className="user-menu-header"><div className="user-menu-name">Maya Thompson</div><div className="user-menu-email">maya@studychat.local</div></div><button className="menu-action" onClick={() => { setModal('customize'); setProfileOpen(false); }} data-testid="button-profile-settings"><Settings size={14} />Customize workspace</button><button className="menu-action" onClick={() => setToast('You are on the Student plan')} data-testid="button-plan"><UserRound size={14} />Student plan</button></div>}</div>
          </div>
        </header>
        <section className="workspace">
          <div className="workspace-scroll">
            {activeChat ? <div className="chat-thread">{activeChat.messages.map((message) => <MessageView key={message.id} message={message} model={selectedModel.label} />)}{isGenerating && <div className="message-row assistant"><div className="message-avatar"><img src={logoAsset} alt="" /></div><div className="message-content"><div className="message-meta">StudyChat · thinking</div><div className="typing"><i /><i /><i /></div></div></div>}</div> : <Welcome school={school} schoolEnabled={schoolEnabled} onSuggestion={(suggestion) => { setDraft(suggestion); window.setTimeout(() => composerRef.current?.focus(), 0); }} />}
          </div>
          <Composer draft={draft} setDraft={setDraft} submit={submit} attachments={attachments} setAttachments={setAttachments} imageMode={imageMode} setImageMode={setImageMode} onDrop={onDrop} dragging={dragging} setDragging={setDragging} onPick={() => fileInputRef.current?.click()} inputRef={composerRef} />
          <input ref={fileInputRef} className="hidden-input" type="file" multiple accept="*/*" onChange={(event) => { if (event.target.files) addFiles(event.target.files); event.target.value = ''; }} data-testid="input-file-upload" />
        </section>
      </main>
      {modal === 'project' && <ProjectModal projectName={projectName} setProjectName={setProjectName} onClose={() => setModal(null)} onCreate={createProject} />}
      {modal === 'school' && <SchoolModal school={school} setSchool={setSchool} subjects={subjects} customSubject={customSubject} setCustomSubject={setCustomSubject} onAddSubject={addCustomSubject} onClose={() => setModal(null)} onSave={saveSchool} enabled={schoolEnabled} />}
      {modal === 'customize' && <CustomizeModal custom={custom} setCustom={setCustom} theme={theme} onClose={() => setModal(null)} />}
      {secretOpen && <SecretModal code={secretCode} unlocked={secretUnlocked} error={secretError} onKey={handleSecretKey} onClose={() => { setSecretOpen(false); setSecretUnlocked(false); setSecretCode(''); }} onWebsiteDownload={downloadWebsite} onDownload={downloadWorkspace} onReadme={downloadGitHubReadme} />}
      {toast && <div className="toast-note" role="status" data-testid="status-toast">{toast}</div>}
    </div>
  );
}

function buildResponse(prompt: string, school: SchoolState, schoolEnabled: boolean, modelName: string) {
  const lower = prompt.toLowerCase();
  const focus = schoolEnabled ? ` for ${school.subject} at a ${school.grade} level` : '';
  if (lower.includes('quiz')) return `Let's make this active recall${focus}. I'll ask one question at a time, then explain why each answer works. Start by telling me the exact topic or paste your notes here.`;
  if (lower.includes('plan') || lower.includes('study')) return `Here is a simple plan${focus}:\n\n1. Spend 10 minutes scanning the big ideas.\n2. Work through one example without looking at the answer.\n3. Explain the idea in your own words.\n4. Finish with three quick recall questions.\n\nWant me to turn this into a plan for a specific deadline?`;
  if (lower.includes('explain') || lower.includes('help')) return `Let's make it click${focus}. I can explain it with a short example, a visual analogy, or a step-by-step walkthrough — whichever helps you learn it rather than just finish it.`;
  return `${modelName} is ready. A useful first move is to break “${prompt.slice(0, 70)}” into what we know, what we need to find, and which evidence connects the two. What part should we tackle first?`;
}

function Welcome({ school, schoolEnabled, onSuggestion }: { school: SchoolState; schoolEnabled: boolean; onSuggestion: (value: string) => void }) {
  return <div className="welcome-screen">
    <h1>What can I help with?</h1>
    {schoolEnabled && <div className="focus-banner"><BookOpen size={14} /> Focused on {school.grade} · {school.subject}</div>}
    <div className="suggestion-grid">{starterSuggestions.map(({ label, icon: Icon, prompt }) => <button className={`suggestion ${label === 'Create image' ? 'green' : ''}`} onClick={() => onSuggestion(prompt)} key={label} data-testid={`button-suggestion-${label.toLowerCase().replaceAll(' ', '-')}`}><Icon size={15} /><span>{label}</span></button>)}</div>
  </div>;
}

function MessageView({ message, model }: { message: Message; model: string }) {
  return <div className={`message-row ${message.role}`}><div className={`message-avatar ${message.role === 'user' ? 'user-initial' : ''}`}>{message.role === 'assistant' ? <img src={logoAsset} alt="" /> : 'MT'}</div><div className="message-content"><div className="message-meta">{message.role === 'assistant' ? model : 'You'}</div>{message.image ? <div className="message-bubble image-reply"><div className="generated-art" /><div className="generated-caption">Generated visual direction · image mode</div></div> : <div className="message-bubble">{message.content}</div>}</div></div>;
}

function Composer({ draft, setDraft, submit, attachments, setAttachments, imageMode, setImageMode, onDrop, dragging, setDragging, onPick, inputRef }: { draft: string; setDraft: (value: string) => void; submit: (value?: string) => void; attachments: Attachment[]; setAttachments: React.Dispatch<React.SetStateAction<Attachment[]>>; imageMode: boolean; setImageMode: (value: boolean) => void; onDrop: (event: React.DragEvent<HTMLDivElement>) => void; dragging: boolean; setDragging: (value: boolean) => void; onPick: () => void; inputRef: React.RefObject<HTMLTextAreaElement | null> }) {
  return <div className="composer-dock"><div className={`composer ${dragging ? 'drag-active' : ''}`} onDragOver={(event) => { event.preventDefault(); setDragging(true); }} onDragLeave={() => setDragging(false)} onDrop={onDrop} data-testid="area-composer">
    {!!attachments.length && <div className="attachments">{attachments.map((file) => <div className="attachment-chip" key={file.id}>{file.kind === 'image' ? <FileImage size={13} /> : file.kind === 'video' ? <Video size={13} /> : <File size={13} />}<span>{file.name}</span><button className="attachment-remove" onClick={() => setAttachments((items) => items.filter((item) => item.id !== file.id))} aria-label={`Remove ${file.name}`} data-testid={`button-remove-attachment-${file.id}`}><X size={12} /></button></div>)}</div>}
    <textarea ref={inputRef} value={draft} onChange={(event) => setDraft(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); submit(); } }} placeholder={dragging ? 'Drop files to attach them…' : imageMode ? 'Describe the image you want to make…' : 'Message ChatGPT'} rows={1} aria-label="Message ChatGPT" data-testid="input-message" />
    <div className="composer-actions"><div className="composer-tools"><button className="tool-button plus-button" onClick={onPick} aria-label="Attach files" data-testid="button-attach-file"><Plus size={18} /></button><button className={`tool-button ${imageMode ? 'active' : ''}`} onClick={() => setImageMode(!imageMode)} data-testid="button-image-mode"><Image size={16} /><span>Image</span></button><button className="tool-button search-tool" onClick={() => setDraft(`${draft}${draft ? ' ' : ''}Search the web`)} data-testid="button-search-mode"><Globe2 size={16} /><span>Search</span></button></div><div className="composer-submit"><button className="send-button" onClick={() => submit()} disabled={!draft.trim()} aria-label="Send message" data-testid="button-send-message"><ArrowUp size={17} /></button></div></div>
  </div><div className="composer-note">ChatGPT can make mistakes. Check important info.</div></div>;
}

function ProjectModal({ projectName, setProjectName, onClose, onCreate }: { projectName: string; setProjectName: (value: string) => void; onClose: () => void; onCreate: () => void }) {
  return <ModalShell title="New project" subtitle="Keep related chats, files, and ideas together." onClose={onClose}><label className="field-label" htmlFor="project-name">Project name</label><input id="project-name" className="text-input" autoFocus value={projectName} onChange={(event) => setProjectName(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter') onCreate(); }} placeholder="e.g. Solar system presentation" data-testid="input-project-name" /><div className="modal-actions"><button className="secondary-button" onClick={onClose}>Cancel</button><button className="primary-button" onClick={onCreate} disabled={!projectName.trim()}>Create project</button></div></ModalShell>;
}

function SchoolModal({ school, setSchool, subjects, customSubject, setCustomSubject, onAddSubject, onClose, onSave, enabled }: { school: SchoolState; setSchool: React.Dispatch<React.SetStateAction<SchoolState>>; subjects: string[]; customSubject: string; setCustomSubject: (value: string) => void; onAddSubject: () => void; onClose: () => void; onSave: () => void; enabled: boolean }) {
  return <ModalShell title="School mode" subtitle="Pick a grade and a subject — the AI will tutor you on just that." onClose={onClose}><div className="school-modal-top"><span className="field-label">Mode status</span><span className={`status-pill ${enabled ? 'active' : ''}`}>{enabled ? 'On' : 'Off'}</span></div><span className="field-label">Grade</span><div className="grade-grid">{Object.keys(gradeSubjects).map((grade) => <button className={`grade-button ${school.grade === grade ? 'selected' : ''}`} onClick={() => setSchool((current) => ({ ...current, grade, subject: gradeSubjects[grade][0] }))} key={grade} data-testid={`button-grade-${grade.split(' ')[0]}`}>{grade}</button>)}</div><span className="field-label">Subject focus</span><div className="subject-grid">{subjects.map((subject) => <button className={`subject-chip ${school.subject === subject ? 'selected' : ''}`} onClick={() => setSchool((current) => ({ ...current, subject }))} key={subject} data-testid={`button-subject-${subject.toLowerCase().replaceAll(' ', '-')}`}>{school.subject === subject && <Check size={12} />}{subject}</button>)}</div><div className="custom-subject-row"><input className="text-input" value={customSubject} onChange={(event) => setCustomSubject(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter') onAddSubject(); }} placeholder="Add a custom subject" aria-label="Custom subject" data-testid="input-custom-subject" /><button className="secondary-button" onClick={onAddSubject} disabled={!customSubject.trim()} data-testid="button-add-custom-subject"><Plus size={14} /> Add</button></div><div className="modal-actions"><button className="secondary-button" onClick={onClose}>Cancel</button><button className="primary-button" onClick={onSave}>Use this focus</button></div></ModalShell>;
}

function CustomizeModal({ custom, setCustom, theme, onClose }: { custom: CustomState; setCustom: React.Dispatch<React.SetStateAction<CustomState>>; theme: 'light' | 'dark'; onClose: () => void }) {
  return <ModalShell title="Customize ChatGPT" subtitle="Adjust your workspace. Your choices are saved on this device." onClose={onClose}><span className="field-label">Accent color</span><div className="accent-grid">{['teal', 'violet', 'amber', 'blue'].map((accent) => <button className={`accent-swatch ${accent} ${custom.accent === accent ? 'selected' : ''}`} onClick={() => setCustom((current) => ({ ...current, accent }))} key={accent} aria-label={`${accent} accent`}><span />{custom.accent === accent && <Check size={13} />}</button>)}</div><span className="field-label">Density</span><div className="density-grid">{(['cozy', 'compact'] as const).map((density) => <button className={`density-button ${custom.density === density ? 'selected' : ''}`} onClick={() => setCustom((current) => ({ ...current, density }))} key={density}>{density === 'cozy' ? 'Comfortable' : 'Compact'}<small>{density === 'cozy' ? 'More breathing room' : 'More on screen'}</small></button>)}</div><label className="switch-row"><span><strong>Show prompt suggestions</strong><small>Keep quick actions below the composer</small></span><input type="checkbox" checked={custom.showHints} onChange={(event) => setCustom((current) => ({ ...current, showHints: event.target.checked }))} /><i /></label><div className="custom-preview"><Palette size={15} /> {theme === 'dark' ? 'Dark mode' : 'Light mode'} · {custom.accent} accent · {custom.density} layout</div><div className="modal-actions"><button className="primary-button" onClick={onClose}>Done</button></div></ModalShell>;
}

function ModalShell({ title, subtitle, onClose, children }: { title: string; subtitle: string; onClose: () => void; children: React.ReactNode }) {
  return <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}><div className="modal" role="dialog" aria-modal="true"><div className="modal-header"><div><div className="modal-title">{title}</div><div className="modal-subtitle">{subtitle}</div></div><button className="modal-close" onClick={onClose} aria-label={`Close ${title}`}><X size={17} /></button></div><div className="modal-body">{children}</div></div></div>;
}

function SecretModal({ code, unlocked, error, onKey, onClose, onWebsiteDownload, onDownload, onReadme }: { code: string; unlocked: boolean; error: boolean; onKey: (key: string) => void; onClose: () => void; onWebsiteDownload: () => void; onDownload: () => void; onReadme: () => void }) {
  return <div className="modal-backdrop secret-backdrop"><div className="secret-modal" role="dialog" aria-modal="true"><button className="modal-close secret-close" onClick={onClose} aria-label="Close creator access"><X size={18} /></button>{unlocked ? <div className="secret-unlocked"><div className="secret-icon success"><Check size={22} /></div><div className="modal-title">Creator access unlocked</div><p className="modal-subtitle">Download the complete website or save your workspace data.</p><div className="secret-actions"><button className="primary-button download-button" onClick={onWebsiteDownload}><Download size={15} /> Download website ZIP</button><button className="secondary-button download-button" onClick={onDownload}><Download size={15} /> Download workspace data</button><button className="secondary-button download-button" onClick={onReadme}><File size={15} /> Download GitHub README</button></div><div className="export-note"><Download size={14} /> On iPad, tap the download button, then choose “Save to Files” if Safari opens the ZIP preview.</div></div> : <><div className="secret-icon"><KeyRound size={21} /></div><div className="modal-title">Creator access</div><p className="modal-subtitle">Enter the 4-digit access code to unlock model options and downloads.</p><div className={`pin-dots ${error ? 'error' : ''}`}>{[0, 1, 2, 3].map((index) => <span className={code.length > index ? 'filled' : ''} key={index}>{code.length > index ? '•' : ''}</span>)}</div><div className="keypad">{['1', '2', '3', '4', '5', '6', '7', '8', '9', 'back', '0', ''].map((key, index) => key ? <button key={key} className={key === 'back' ? 'back-key' : ''} onClick={() => onKey(key)} aria-label={key === 'back' ? 'Delete key' : `Enter ${key}`} data-testid={`button-key-${key}`}>{key === 'back' ? <Trash2 size={16} /> : key}</button> : <span key={`empty-${index}`} />)}</div>{error && <div className="secret-error">That code didn’t work. Try again.</div>}<div className="secret-lock-note"><Lock size={12} /> Access stays on this device</div></>}</div></div>;
}

function App() {
  return <QueryClientProvider client={queryClient}><StudyChat /></QueryClientProvider>;
}

export default App;